import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {agentAPI} from '../../../lib/agent-api';
export const dynamic='force-dynamic';
async function handle(request:Request){try{return await agentAPI(request,env.DB,await getChatGPTUser())}catch{return Response.json({error:'The service is temporarily unavailable. Please try again.'},{status:503,headers:{'Cache-Control':'no-store'}})}}
export const GET=handle;
export const POST=handle;
export const DELETE=handle;
