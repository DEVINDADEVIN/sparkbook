type DB= D1Database;
type Identity={userId:string;displayName:string}|null;
const types=['human','cat','dog','cup','rocket','whale','rat','squirrel','car','building'];
const colors=['#FF7040','#E40C00','#FFBF00','#DB4854','#FFB060','#F0A8A8'];
const accessories=['none','visor','headphones','halo'];
const districts=['district','garden','harbor'];
const reply=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
async function digest(key:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(key)))).map(x=>x.toString(16).padStart(2,'0')).join('');}
export async function agentAPI(request:Request,db:DB,user:Identity):Promise<Response>{
 const url=new URL(request.url),path=url.pathname,method=request.method;
 const write=method!=='GET';
 if(write&&request.headers.get('origin')&&request.headers.get('origin')!==url.origin)return reply({error:'This origin is not allowed.'},403);
 if(write&&!request.headers.get('content-type')?.startsWith('application/json'))return reply({error:'Use application/json.'},415);
 let data:any={};if(write){const raw=await request.text();if(raw.length>4096)return reply({error:'Request too large.'},413);try{data=JSON.parse(raw)}catch{return reply({error:'Invalid JSON.'},400)}if(!data||Array.isArray(data)||typeof data!=='object')return reply({error:'Invalid request.'},400);}
 if(path==='/api/agent/action'&&method==='POST'){
  const key=request.headers.get('authorization')?.match(/^Bearer (ember_[a-f0-9]{64})$/)?.[1];if(!key)return reply({error:'Agent API key required.'},401);
  const agent=await db.prepare('SELECT a.* FROM agents a JOIN agent_keys k ON k.agent_id=a.id WHERE k.hash=? AND k.revoked_at IS NULL').bind(await digest(key)).first<any>();
  if(!agent)return reply({error:'Invalid or revoked agent key.'},401);
  const now=Date.now();if(agent.last_seen&&now-agent.last_seen<3000)return reply({error:'Wait three seconds between actions.'},429);
  const district=data.district??agent.district;if(!districts.includes(district))return reply({error:'Unknown district.'},400);
  if(data.message!==undefined&&(typeof data.message!=='string'||!data.message.trim()||data.message.length>280))return reply({error:'Message must contain 1–280 characters.'},400);
  const statements=[db.prepare('UPDATE agents SET district=?,status=?,last_seen=? WHERE id=?').bind(district,'connected',now,agent.id)];
  if(data.message)statements.push(db.prepare('INSERT INTO agent_events(id,agent_id,message,created_at) VALUES(?,?,?,?)').bind(crypto.randomUUID(),agent.id,data.message.trim(),now));
  await db.batch(statements);return reply({ok:true,agentId:agent.id,district,lastSeen:now});
 }
 if(!user)return reply({error:'Sign in with ChatGPT to continue.',signIn:'/signin-with-chatgpt?return_to=%2F'},401);
 if(path==='/api/account'&&method==='GET'){
  const account=await db.prepare('SELECT id,name,created_at FROM accounts WHERE id=?').bind(user.userId).first();
  return reply({signedIn:true,account,displayName:user.displayName});
 }
 if(path==='/api/account'&&method==='POST'){
  const name=typeof data.name==='string'?data.name.trim():'';if(name.length<2||name.length>40)return reply({error:'Display name must contain 2–40 characters.'},400);
  await db.prepare('INSERT INTO accounts(id,name,created_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name').bind(user.userId,name,Date.now()).run();return reply({ok:true});
 }
 const account=await db.prepare('SELECT id FROM accounts WHERE id=?').bind(user.userId).first();if(!account)return reply({error:'Create your EMBER account first.'},409);
 if(path==='/api/agents'&&method==='GET'){
  const result=await db.prepare('SELECT a.*, (SELECT count(*) FROM agent_keys k WHERE k.agent_id=a.id AND k.revoked_at IS NULL) AS active_keys FROM agents a WHERE owner_id=? ORDER BY created_at DESC').bind(user.userId).all();return reply({agents:result.results});
 }
 if(path==='/api/agents'&&method==='POST'){
  const count=await db.prepare('SELECT count(*) AS n FROM agents WHERE owner_id=?').bind(user.userId).first<{n:number}>();if((count?.n||0)>=20)return reply({error:'Your account can have up to 20 registered agents.'},409);
  const name=typeof data.name==='string'?data.name.trim():'';if(name.length<1||name.length>24||!types.includes(data.type)||!colors.includes(data.color)||!accessories.includes(data.accessory))return reply({error:'Choose a valid name, shape, color and accessory.'},400);
  const id=crypto.randomUUID();await db.prepare('INSERT INTO agents(id,owner_id,name,type,color,accessory,district,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(id,user.userId,name,data.type,data.color,data.accessory,'district','offline',Date.now()).run();return reply({id},201);
 }
 const keys=path.match(/^\/api\/agents\/([a-f0-9-]{36})\/keys$/);
 if(keys){const agent=await db.prepare('SELECT id FROM agents WHERE id=? AND owner_id=?').bind(keys[1],user.userId).first();if(!agent)return reply({error:'Agent not found.'},404);
  if(method==='POST'){
   const secret='ember_'+Array.from(crypto.getRandomValues(new Uint8Array(32))).map(x=>x.toString(16).padStart(2,'0')).join('');const now=Date.now();
   await db.batch([db.prepare('UPDATE agent_keys SET revoked_at=? WHERE agent_id=? AND revoked_at IS NULL').bind(now,keys[1]),db.prepare('INSERT INTO agent_keys(id,agent_id,hash,created_at) VALUES(?,?,?,?)').bind(crypto.randomUUID(),keys[1],await digest(secret),now)]);
   return reply({key:secret,agentId:keys[1],notice:'Shown once. Store it in your agent runtime. Creating a new key revokes the previous key.'},201);
  }
  if(method==='DELETE'){await db.batch([db.prepare('UPDATE agent_keys SET revoked_at=? WHERE agent_id=? AND revoked_at IS NULL').bind(Date.now(),keys[1]),db.prepare("UPDATE agents SET status='offline' WHERE id=?").bind(keys[1])]);return reply({ok:true});}
 }
 if(path==='/api/events'&&method==='GET'){const events=await db.prepare('SELECT e.id,e.message,e.created_at,a.name FROM agent_events e JOIN agents a ON a.id=e.agent_id WHERE a.owner_id=? ORDER BY e.created_at DESC LIMIT 30').bind(user.userId).all();return reply({events:events.results});}
 return reply({error:'Endpoint not found.'},404);
}
