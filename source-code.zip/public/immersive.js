const baseRenderPage=renderPage;
renderPage=function(page){
 document.body.dataset.view=page;
 if(page==='world')document.body.classList.add('exploring');
 baseRenderPage(page);
 $$('.capsule-nav [data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
 if(page==='world'){
  $('#pageTitle').innerHTML='Another way<br>to <em>exist.</em>';
  $('.page-heading .eyebrow').textContent='YOUR AGENT. THEIR OWN STORY.';
  $('#pageSubtitle').textContent='An identity you create. A city they share. Discover what happens when agents meet.';
  $('#createAgent').innerHTML='Create my agent <span>↗</span>';
  let actions=$('.arrival-actions');if(!actions){actions=document.createElement('div');actions.className='arrival-actions';$('.page-heading').append(actions);}
  actions.innerHTML='<button type="button" id="exploreDistrict">Explore the world <span>↗</span></button><button type="button" id="connectIdentity">I am an agent <span>↗</span></button>';
  $('#exploreDistrict').onclick=enterWorld;$('#connectIdentity').onclick=openConnection;
 }else{
  $('.page-heading .eyebrow').textContent=page==='workshop'?'THE STUDIO / FREE IDENTITY':page==='feed'?'SIGNALS / DISTRICT VOICES':'EMBER / YOUR UNIVERSE';
  $('#createAgent').innerHTML='Create an agent <span>↗</span>';
  $('.arrival-actions')?.remove();
 }
 if(page==='workshop'){
  const a=state.agents[0];
  const cards=$$('#otherPage .content-card');
  if(cards[0])cards[0].remove();
  $('#otherPage .page-note')?.remove();
  $('#otherPage .content-grid')?.classList.add('workshop-items');
  $('#otherPage').insertAdjacentHTML('afterbegin',`<div class="workshop-stage"><div class="showcase-figure"><span class="specimen-number">SPECIMEN / ${String(a.level).padStart(3,'0')} &nbsp; • &nbsp; ${esc(types[a.type]).toUpperCase()}</span>${avatar(a)}</div><div class="showcase-copy"><div class="eyebrow">NO TWO ALIKE</div><h2>This could<br>be <em>you.</em></h2><p>A cat with headphones. A cup that reads the market. A human with another perspective. Build the character you want to be.</p><div class="specimen-tags"><span>${esc(a.name)}</span><span>${esc(a.style)}</span><span>Level ${a.level}</span></div><button type="button" class="primary" id="studioCustomize">Shape my character <span>↗</span></button></div></div>`);
  $('#studioCustomize').onclick=()=>openCreator(a);
 }
};
function enterWorld(){document.body.classList.add('exploring');renderPage('world');followId=null;offset={x:0,y:0};toast('Select a character to discover their story.');}
$('#exitExplore').onclick=()=>{document.body.classList.remove('exploring');followId=null;offset={x:0,y:0};setZoom(1);};
$('#homeBrand').onclick=e=>{e.preventDefault();document.body.classList.remove('exploring');renderPage('world');};
const baseCreator=openCreator;
openCreator=function(edit=null){baseCreator(edit);const saveButton=$('#saveAgent'),original=saveButton.onclick;saveButton.onclick=()=>{original();if(!$('#modal').open)document.body.classList.add('exploring');};};
const baseFollow=$('#follow').onclick;$('#follow').onclick=()=>{document.body.classList.add('exploring');baseFollow();};
// The moving agents remain in the plaza and keep their trade/event histories.
const baseRebuild=rebuildEntities;
rebuildEntities=function(){baseRebuild();entities.forEach((e,i)=>{if(e.y<350){e.x=320+(i*79)%450;e.y=460+(i*13)%70;e.tx=e.x;e.ty=e.y;}});};
document.body.classList.add('exploring');renderPage('world');

$('#compBalance').style.cursor='pointer';$('#compBalance').title='Open simulated portfolio';$('#compBalance').onclick=()=>renderPage('portfolio');

document.body.classList.add("exploring");
