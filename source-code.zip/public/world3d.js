import * as THREE from 'three';
import { OrbitControls } from './vendor/OrbitControls.js';

const B=window.emberWorld;
const mount=document.querySelector('.world-viewport');
const oldCanvas=document.querySelector('#world');
const canvas3d=document.createElement('canvas');canvas3d.id='world';canvas3d.tabIndex=0;canvas3d.setAttribute('aria-label','3D universe: drag to orbit, scroll to zoom and select a character.');oldCanvas.replaceWith(canvas3d);
const labels=document.createElement('div');labels.className='world-labels';mount.append(labels);
const loading=document.createElement('div');loading.className='world-loading';loading.textContent='Building your world…';mount.append(loading);
let renderer;
try{renderer=new THREE.WebGLRenderer({canvas:canvas3d,antialias:true,alpha:true,powerPreference:'high-performance'});}catch(err){loading.textContent='Your browser could not start the 3D world. Enable graphics acceleration and reload.';throw err;}
renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.3;
const scene=new THREE.Scene();scene.fog=new THREE.FogExp2('#261511',.009);
const camera=new THREE.OrthographicCamera(-16,16,12,-12,.1,160);camera.position.set(24,29,28);
const controls=new OrbitControls(camera,canvas3d);controls.target.set(0,.25,0);controls.enableDamping=true;controls.dampingFactor=.08;controls.minZoom=.55;controls.maxZoom=5;controls.minPolarAngle=.08;controls.maxPolarAngle=Math.PI*.42;controls.maxTargetRadius=34;controls.rotateSpeed=.7;controls.zoomSpeed=.8;controls.enablePan=true;controls.screenSpacePanning=false;controls.update();
scene.add(new THREE.HemisphereLight('#ffe6bb','#514350',2.0));
const sun=new THREE.DirectionalLight('#ffcd95',3.2);sun.position.set(-20,35,20);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);sun.shadow.camera.left=-34;sun.shadow.camera.right=34;sun.shadow.camera.top=34;sun.shadow.camera.bottom=-34;sun.shadow.camera.near=.5;sun.shadow.camera.far=110;sun.shadow.normalBias=.04;sun.shadow.bias=-.0001;scene.add(sun);
const rim=new THREE.DirectionalLight('#ff7040',2);rim.position.set(12,8,-14);scene.add(rim);
const world=new THREE.Group();scene.add(world);
const architecture=new THREE.Group();world.add(architecture);
const animated=[];const environmentGroups={};const materialCache=new Map();
function mat(color,glow=0){const key=color+':'+glow;if(!materialCache.has(key))materialCache.set(key,new THREE.MeshStandardMaterial({color,roughness:.76,metalness:.05,emissive:glow?color:0,emissiveIntensity:glow}));return materialCache.get(key);}
function mesh(geo,color,parent,x=0,y=0,z=0,glow=0){const o=new THREE.Mesh(geo,mat(color,glow));o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;}
function box(parent,w,h,d,x,y,z,c,glow=0){return mesh(new THREE.BoxGeometry(w,h,d),c,parent,x,y,z,glow);}
function cyl(parent,r,h,x,y,z,c,n=20,rTop=r,glow=0){return mesh(new THREE.CylinderGeometry(rTop,r,h,n),c,parent,x,y,z,glow);}
function ball(parent,r,x,y,z,c,sx=1,sy=1,sz=1){const o=mesh(new THREE.SphereGeometry(r,16,12),c,parent,x,y,z);o.scale.set(sx,sy,sz);return o;}
function torus(parent,r,t,x,y,z,c){return mesh(new THREE.TorusGeometry(r,t,8,32),c,parent,x,y,z);}
function group(parent,x=0,y=0,z=0){const g=new THREE.Group();g.position.set(x,y,z);parent.add(g);return g;}
function beam(parent,a,b,r,c){const av=new THREE.Vector3(...a),bv=new THREE.Vector3(...b),d=bv.clone().sub(av);const o=cyl(parent,r,d.length(),...av.clone().add(bv).multiplyScalar(.5).toArray(),c,8);o.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize());return o;}
function textSign(parent,text,w,h,x,y,z,color='#ffd397',bg='#291c22'){
 const c=document.createElement('canvas');c.width=512;c.height=160;const cc=c.getContext('2d');cc.fillStyle=bg;cc.fillRect(0,0,512,160);cc.strokeStyle=color;cc.lineWidth=5;cc.strokeRect(8,8,496,144);cc.fillStyle=color;cc.font='bold 62px sans-serif';cc.textAlign='center';cc.textBaseline='middle';cc.fillText(text,256,83,475);const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;const o=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:tex,side:THREE.DoubleSide}));o.position.set(x,y,z);parent.add(o);return o;
}
// A tangible floating island: its bottom, sidewalks, floors and facades are meshes.
// 48 × 32 walkable world, over 3.7 times the original island area.
box(world,48,1.5,32,0,-.86,0,'#352b30');box(world,48.25,.18,32.25,0,-.08,0,'#d79c72');box(world,47.9,.12,31.9,0,.04,0,'#71574b');
const tiles=new THREE.InstancedMesh(new THREE.BoxGeometry(1.475,.035,1.475),mat('#806151'),32*21);let tileIndex=0;const tileMatrix=new THREE.Matrix4();
for(let x=-23.25;x<24;x+=1.5)for(let z=-15;z<=15;z+=1.5){tileMatrix.makeTranslation(x,.12,z);tiles.setMatrixAt(tileIndex++,tileMatrix);}tiles.receiveShadow=true;world.add(tiles);
const roadXs=[-20,-16,-12,-8,-4,0,4,8,12,16,20],roadZs=[-11,-3.5,3.5,11];
for(const z of roadZs){box(world,44,.045,2.15,0,.16,z,'#b28a6c');for(let x=-21;x<=21;x++)box(world,.55,.02,.045,x,.19,z,'#dcc39e');}
for(const x of [-20,-12,12,20])box(world,1.75,.04,23,x,.185,0,'#b28a6c');
for(const x of [-8,-4,4,8])box(world,1.75,.04,14.5,x,.185,3.75,'#b28a6c');
for(const z of [-16.03,16.03])box(world,47.7,.035,.05,0,-.4,z,'#ff7040',2);
for(const x of [-24.03,24.03])box(world,.045,.035,31.7,x,-.4,0,'#ff7040',2);
const ground=mesh(new THREE.CircleGeometry(100,64),'#281a20',scene,0,-2.35,0);ground.rotation.x=-Math.PI/2;ground.castShadow=false;
// Architecture, air conditioners, roof gardens, cables and readable storefronts.
function building(x,z,w,d,h,color,name,accent='#ffb060'){
 const g=group(architecture,x,.2,z);box(g,w,h,d,0,h/2,0,color);box(g,w+.2,.16,d+.2,0,h+.04,0,'#39303a');box(g,w+.3,.18,d+.3,0,.14,0,'#3d3033');
 for(let y=1.5;y<h-.3;y+=.72)for(let a=-w/2+.37;a<w/2-.2;a+=.62){box(g,.29,.38,.055,a,y,d/2+.03,((a+y)*10)%3>1?accent:'#795e55',.45);box(g,.055,.38,.28,w/2+.03,y,a*d/w,accent,.3);}
 box(g,w*.72,.86,.08,0,.67,d/2+.05,'#33272c');for(let a=-w*.3;a<w*.32;a+=.4)box(g,.05,.84,.1,a,.67,d/2+.11,'#dba476');
 box(g,w+.4,.12,.85,0,1.3,d/2+.3,color);box(g,w+.35,.045,.04,0,1.24,d/2+.71,accent,1.5);
 textSign(g,name,w*.93,.57,0,1.83,d/2+.11,accent);box(g,.65,.45,.65,-w*.22,h+.28,-d*.15,'#938375');for(let i=0;i<4;i++)box(g,.5,.04,.035,-w*.22,h+.49,-d*.38+i*.1,'#564a49');
 const tank=cyl(g,.36,.6,w*.23,h+.38,-d*.2,'#816b62');cyl(g,.38,.08,w*.23,h+.72,-d*.2,'#453b3d');beam(g,[w*.2,h+.75,-d*.2],[w*.2,h+1.6,-d*.2],.025,'#bb9f82');ball(g,.07,w*.2,h+1.6,-d*.2,'#ff7040');
 box(g,.055,h-.3,.08,-w/2-.025,h/2+.1,d/2-.1,accent,1.2);return g;
}
building(-7,-6.5,3.5,2.8,3.7,'#9e5345','NOODLE');building(-2.2,-6.45,3.7,2.9,2.4,'#bd7854','EMBER / 01');building(3,-6.6,3.2,2.6,4.5,'#6a5357','EXCHANGE','#ffc86c');building(8,-6.1,2.7,3.7,5.7,'#85504e','AGENT CLUB','#f0a8a8');
// A terrace on the central store, a side stair and a slowly turning roof fan.
for(let i=0;i<5;i++)box(architecture,1.25,.19,1.3,-4.65,.27+i*.2,-6.8+i*.27,'#d2996b');
for(let i=0;i<7;i++){box(architecture,.035,.5,.04,-3.9+i*.48,2.8,-4.98,'#e4b488');}box(architecture,3.1,.035,.04,-2.4,3.05,-4.98,'#e4b488');
const fan=group(architecture,3,5.3,-6.6);for(let i=0;i<3;i++){const blade=box(fan,.15,.045,1.2,0,0,.45,'#a58b7b');blade.rotation.y=i*Math.PI*2/3;}animated.push({object:fan,kind:'fan'});
function tree(parent,x,z,scale=1){const g=group(parent,x,.2,z);g.scale.setScalar(scale);cyl(g,.13,1.05,0,.53,0,'#786052',8);beam(g,[0,.6,0],[.36,1.2,.08],.08,'#786052');for(const [a,b,c,r,col]of [[0,1.6,0,.65,'#db7755'],[-.38,1.37,.1,.47,'#ba644b'],[.4,1.45,.12,.5,'#ef9b62'],[.02,1.5,-.4,.46,'#cf7c58']])mesh(new THREE.IcosahedronGeometry(r,1),col,g,a,b,c);box(g,1.3,.3,1.3,0,.05,0,'#6a4d44');box(g,1.15,.07,1.15,0,.23,0,'#473b33');return g;}
tree(architecture,-10,6.6,1.05);tree(architecture,9.65,6.3,1.35);tree(architecture,-10,-6.5,.85);tree(architecture,5.6,7,.85);
function lamp(x,z){const g=group(architecture,x,.2,z);cyl(g,.14,.18,0,.09,0,'#55414a');cyl(g,.045,2.4,0,1.2,0,'#48383d',8);beam(g,[0,2.35,0],[.5,2.35,0],.04,'#48383d');box(g,.55,.11,.3,.46,2.32,0,'#ffe1a2',1.6);const light=new THREE.PointLight('#ffb56f',2.8,3.8,2);light.position.set(.46,2.05,0);g.add(light);}
for(const [x,z]of [[-9.3,-2.2],[-5.2,2.2],[5.2,2.2],[9.6,-2.2],[-1.9,-3.8]])lamp(x,z);
function bench(x,z,r=0){const g=group(architecture,x,.22,z);g.rotation.y=r;for(let i=0;i<3;i++)box(g,1.55,.09,.15,0,.45,i*.2,'#ce9060');box(g,1.55,.55,.09,0,.77,.5,'#aa6b4c');for(const a of [-.58,.58]){box(g,.12,.45,.55,a,.23,.2,'#4b3a3c');box(g,.12,.8,.1,a,.55,.49,'#4b3a3c');}return g;}
bench(-5.8,1.4,Math.PI/2);bench(5.6,-1.5,-Math.PI/2);bench(2.1,6.2,Math.PI);
function stall(x,z){const g=group(architecture,x,.2,z);box(g,2.1,.85,1.1,0,.44,0,'#a45b45');box(g,2.3,.13,1.25,0,.91,0,'#dcad78');for(const a of [-.93,.93])cyl(g,.035,2.1,a,1.05,.35,'#684a3c',8);for(let i=0;i<7;i++)box(g,.32,.13,1.65,-.96+i*.32,2.03,0,i%2?'#ffc18a':'#dd6545');textSign(g,'COFFEE',1.65,.42,0,.5,.565);for(let i=0;i<3;i++)cyl(g,.1,.18,-.45+i*.35,1.06,0,'#fff0d9');}
stall(-6,6.4);
// Central meeting point with a rotating crystal and an actual recessed basin.
const hub=group(architecture,0,.22,0);cyl(hub,1.48,.3,0,.15,0,'#725452',48);cyl(hub,1.28,.1,0,.33,0,'#bc8867',48);cyl(hub,1.12,.045,0,.4,0,'#cd7355',48,1.12,.3);const rimRing=torus(hub,1.3,.08,0,.43,0,'#f5c899');rimRing.rotation.x=Math.PI/2;cyl(hub,.37,.65,0,.65,0,'#60414a');const crystal=mesh(new THREE.OctahedronGeometry(.63,0),'#ff9f60',hub,0,1.5,0,.65);animated.push({object:crystal,kind:'crystal'});const orbit=torus(hub,.89,.025,0,1.5,0,'#ffcc80');orbit.rotation.x=.95;animated.push({object:orbit,kind:'ring'});
// Small details make the island feel inhabited at every camera angle.
for(const [x,z]of [[-10,0],[10,0]]){const g=group(architecture,x,.22,z);box(g,.65,1.25,.65,0,.63,0,'#d26946');box(g,.46,.65,.04,0,.82,.35,'#ffd487',.55);for(let i=0;i<3;i++)box(g,.35,.04,.03,0,.6+i*.17,.38,'#754b43');textSign(g,'24H',.47,.22,0,1.37,.1);}
for(const [x,z]of [[-5.5,-.5],[6,5.5],[-8.8,4.8]]){cyl(architecture,.25,.48,x,.44,z,'#5c5150',12);cyl(architecture,.27,.06,x,.71,z,'#d69664',12);}
// The park, market and waterfront are always present in the same world.
for(let x=-23;x<=23;x+=2){cyl(architecture,.025,.5,x,.47,15.5,'#ad826d',8);}
beam(architecture,[-23,.7,15.5],[23,.7,15.5],.025,'#d5a37b');
building(-16,-7,4.8,3.6,3.1,'#98514b','ARCADE');building(-16,-14,4.8,2.5,4,'#b37454','ORBITAL');
building(-7,-14,5,2.5,3,'#b57859','RESIDENCES');building(0,-14,5,2.5,4.1,'#80575a','SIGNAL LAB');building(8,-14,4,2.5,3.4,'#b16c50','STUDIO');
building(16,-7,4.8,3.5,4,'#825962','HARBOR HOUSE');building(16,-14,5,2.5,2.8,'#ac674d','DOCK 03');
const garden=group(world);environmentGroups.garden=garden;
for(const [x,z] of [[-17,-.9],[-15,1],[-17,6.2],[-15,8.4],[-22,6],[-22,-7],[-10,14],[-17,14],[-22,14]])tree(garden,x,z,1.15);
box(garden,5.4,.08,5.5,-16,.2,7,'#6b7358');for(const x of [-18,-14])for(const z of [5,9])tree(garden,x,z,.75);
bench(-17,0);bench(-15,8,Math.PI);textSign(garden,'ORBITAL GARDEN',4,.65,-16,1.3,2.25,'#ffe2af');
const harbor=group(world);environmentGroups.harbor=harbor;
box(harbor,5.7,.08,5.3,16,.19,7,'#586e75');box(harbor,5.8,.13,.5,16,.27,9.5,'#bc8961');
for(let i=0;i<8;i++)box(harbor,.055,.035,4.6,13.55+i*.7,.26,7,'#759191');
for(const x of [14,18]){box(harbor,1.1,.18,3.2,x,.32,7.9,'#b58b68');for(const z of [6.5,9])cyl(harbor,.065,.6,x,.51,z,'#624c46',8);}
const boat=group(harbor,16,.3,6);box(boat,1.2,.4,2,0,.2,0,'#ed975f');box(boat,.8,.45,.75,0,.6,-.25,'#ffdfb0');box(boat,.65,.23,.05,0,.65,.15,'#564b57');
textSign(harbor,'RED HARBOR',3.5,.65,16,1.3,2.25,'#ffc88c');
stall(-7,14);stall(0,14);stall(7,14);bench(12,14);bench(20,14);tree(architecture,22,14,1.2);tree(architecture,22,-14,1.3);
for(const [x,z] of [[-21,-9],[-13,2],[-21,10],[13,-9],[21,2],[21,10],[-5,10],[5,10]])lamp(x,z);
// Grid links follow open roads; blocked center columns protect buildings and fountain.
const nodes=[],links=[];
for(const z of roadZs)for(const x of roadXs)nodes.push(new THREE.Vector3(x,.23,z));
for(let row=0;row<4;row++)for(let col=0;col<10;col++)links.push([row*11+col,row*11+col+1]);
for(let row=0;row<3;row++)for(const col of (row===0?[0,2,8,10]:[0,2,3,4,6,7,8,10]))links.push([row*11+col,(row+1)*11+col]);
const adjacency=nodes.map((_,i)=>links.flatMap(([a,b])=>a===i?[b]:b===i?[a]:[]));
const agents=new Map();
function model(data){
 const root=new THREE.Group(),body=group(root),limbs=[],eyeParts=[];const col=data.color||'#ff7040',dark='#342b35',cream='#ffe1b4';let headY=1.15,headZ=.3;
 const leg=(x,z=0)=>{const pivot=group(body,x,.4,z);box(pivot,.15,.35,.18,0,-.14,0,dark);box(pivot,.18,.11,.27,0,-.34,.06,'#f5b87b');limbs.push(pivot);};
 const arm=(x)=>{const pivot=group(body,x,.78,0);box(pivot,.15,.36,.18,0,-.13,0,col);ball(pivot,.09,0,-.36,0,cream);limbs.push(pivot);};
 const eyes=(y,z,wide=.14)=>{for(const x of [-wide,wide]){
 const eye=group(body,x,y,z);ball(eye,.085,0,0,0,cream,.85,1.2,.42);ball(eye,.065,0,0,.03,dark,.72,1.2,.45);ball(eye,.036,0,-.015,.056,col,.85,1,.3);ball(eye,.024,-.016,.032,.064,'#fff4df');eyeParts.push(eye);
 const brow=box(body,.12,.022,.025,x,y+.112,z+.014,dark);brow.rotation.z=x<0?-.12:.12;
 ball(body,.043,x*1.45,y-.09,z-.006,'#DB4854',1,.4,.25);
 }const smile=torus(body,.048,.009,0,y-.1,z+.025,dark);smile.scale.y=.55;};
 if(data.type==='human'){
  leg(-.15);leg(.15);box(body,.5,.46,.29,0,.68,0,col);box(body,.08,.41,.025,0,.69,.16,dark);arm(-.34);arm(.34);ball(body,.31,0,1.19,0,cream,1,1.15,.94);ball(body,.32,0,1.34,-.055,'#f3dfbd',1.07,.76,1);for(let i=0;i<5;i++){const fringe=mesh(new THREE.ConeGeometry(.09,.25,4),'#f3dfbd',body,-.24+i*.12,1.38,.23);fringe.rotation.z=Math.PI+(i-2)*.14;}eyes(1.19,.288);headY=1.22;headZ=.32;
 }else if(['cat','dog','rat','squirrel'].includes(data.type)){
  leg(-.15);leg(.15);ball(body,.29,0,.62,0,col,1,1.15,.8);ball(body,.21,0,.64,.18,cream,.9,1,.4);ball(body,.37,0,1.08,0,col,1.04,.95,.88);arm(-.3);arm(.3);eyes(1.1,.314,.16);ball(body,.043,0,1.02,.36,dark,1,.7,.7);
  if(data.type==='cat')for(const x of [-.25,.25]){const ear=mesh(new THREE.ConeGeometry(.17,.3,3),col,body,x,1.44,-.035);ear.rotation.z=x*.7;const inner=mesh(new THREE.ConeGeometry(.095,.19,3),'#f0a8a8',body,x,1.45,.055);}
  else if(data.type==='dog')for(const x of [-.34,.34])ball(body,.17,x,1.11,-.015,'#9b5d40',.7,1.8,.7);
  else for(const x of [-.29,.29]){ball(body,.21,x,1.38,-.03,col,1,1,.55);ball(body,.14,x,1.38,.064,'#f0a8a8',1,1,.3);}
  const tail=group(body,0,.5,-.22);if(data.type==='squirrel')ball(tail,.34,0,.24,-.3,col,.8,1.7,.9);else{const curve=new THREE.CatmullRomCurve3([new THREE.Vector3(0,0,0),new THREE.Vector3(.1,.12,-.4),new THREE.Vector3(.3,.36,-.5)]);mesh(new THREE.TubeGeometry(curve,10,.06,7,false),col,tail);}root.userData.tail=tail;headY=1.1;headZ=.36;
 }else if(data.type==='cup'){
  leg(-.18);leg(.18);cyl(body,.39,.64,0,.78,0,col,32,.43);cyl(body,.365,.025,0,1.105,0,'#5b382a',32);const lip=torus(body,.406,.035,0,1.13,0,cream);lip.rotation.x=Math.PI/2;const handle=torus(body,.235,.069,.45,.8,0,col);eyes(.84,.402,.16);headY=.85;headZ=.43;
 }else if(data.type==='rocket'){
  cyl(body,.28,.7,0,.8,0,cream,20,.28);mesh(new THREE.ConeGeometry(.29,.42,20),col,body,0,1.36,0);for(let i=0;i<3;i++){const fin=mesh(new THREE.ConeGeometry(.2,.48,3),col,body,Math.sin(i*2.094)*.31,.54,Math.cos(i*2.094)*.31);fin.rotation.z=.3;}
  ball(body,.2,0,.91,.21,'#5b3a43',1,1,.6);eyes(.93,.333,.09);const flame=mesh(new THREE.ConeGeometry(.18,.5,12),'#ffc75c',body,0,.16,0,1);flame.rotation.z=Math.PI;root.userData.flame=flame;headY=.94;headZ=.36;
 }else if(data.type==='whale'){
  ball(body,.5,0,.83,0,col,1.25,.8,.8);ball(body,.43,0,.66,.15,cream,1.25,.55,.65);eyes(.92,.387,.21);for(const x of [-.57,.57]){const fin=ball(body,.2,x,.65,.02,col,1.5,.2,.7);fin.rotation.z=-x*.3;limbs.push(fin);}const tail=group(body,0,.9,-.47);ball(tail,.25,-.18,.05,-.13,col,1.2,.2,.8);ball(tail,.25,.18,.05,-.13,col,1.2,.2,.8);root.userData.tail=tail;headY=.98;headZ=.43;
 }else if(data.type==='car'){
  box(body,.85,.28,1.0,0,.42,0,col);box(body,.62,.29,.57,0,.7,-.06,col);box(body,.52,.21,.02,0,.73,.24,'#423744');eyes(.47,.515,.21);for(const x of [-.43,.43])for(const z of [-.32,.32]){const wheel=cyl(body,.17,.13,x,.27,z,dark,16);wheel.rotation.z=Math.PI/2;limbs.push(wheel);}for(const x of [-.3,.3])box(body,.13,.065,.03,x,.52,.53,cream,1);headY=.8;headZ=.36;
 }else{
  leg(-.2);leg(.2);box(body,.67,.87,.55,0,.83,0,col);box(body,.79,.1,.67,0,1.31,0,cream);for(const x of [-.19,.19])for(const y of [.65,1.09])box(body,.13,.16,.03,x,y,.295,'#ffc984',.4);eyes(.89,.302);cyl(body,.025,.34,.2,1.52,0,dark,8);headY=1;headZ=.34;
 }
 // Layered streetwear and mechanical details keep each silhouette readable from above.
 if(['human','cat','dog','rat','squirrel'].includes(data.type)){
 box(body,.54,.14,.34,0,.48,0,dark);box(body,.09,.065,.035,0,.48,.19,'#FFBF00',.3);
 for(const x of [-.24,.24]){const collar=box(body,.14,.22,.05,x*.55,.88,.18,dark);collar.rotation.z=x<0?-.4:.4;box(body,.12,.11,.035,x*.65,.65,.24,'#FFB060');}
 const pack=group(body,0,.72,-.23);box(pack,.32,.38,.16,0,0,0,dark);box(pack,.2,.055,.025,0,.05,-.09,col,1);cyl(pack,.045,.24,.21,.06,0,'#FFB060',8);
 for(const x of [-.34,.34]){ball(body,.115,x,.79,0,dark,1,.7,1);box(body,.13,.028,.14,x,.85,.015,col,.4);}
 }
 if(data.type==='cat'){for(const side of [-1,1])for(let i=0;i<2;i++)beam(body,[side*.22,1.01-i*.04,.3],[side*.42,1.03-i*.08,.25],.009,cream);}
 if(data.type==='cup'){box(body,.5,.23,.03,0,.71,.385,dark);box(body,.15,.045,.035,0,.72,.409,'#FFBF00',.5);const steam=group(body,0,1.28,0);for(let i=0;i<3;i++)ball(steam,.045,(i-1)*.13,i*.09,0,cream,.6,1.5,.6);root.userData.steam=steam;}
 if(data.type==='rocket'){const rim=torus(body,.205,.028,0,.91,.3,'#FFBF00');for(const x of [-.12,.12])box(body,.055,.19,.02,x,.65,.265,col);}
 if(data.type==='car'){box(body,.75,.065,.13,0,.59,-.5,dark);for(const x of [-.44,.44])ball(body,.06,x,.76,.13,col,1,.6,1);box(body,.31,.06,.02,0,.37,.51,dark);}
 if(data.type==='building'){box(body,.29,.22,.035,0,.54,.3,dark);box(body,.1,.035,.04,0,.59,.33,'#FFBF00',1);ball(body,.07,.2,1.7,0,col);}
 root.userData.eyes=eyeParts;
 if(data.accessory==='visor'){box(body,.69,.115,.035,0,headY+.02,headZ,'#ffae61',.6);box(body,.53,.024,.04,0,headY+.025,headZ+.025,'#ffeac5',.8);}
 if(data.accessory==='headphones'){const band=torus(body,.38,.04,0,headY,0,'#49333c');band.rotation.y=0;for(const x of [-.39,.39])ball(body,.12,x,headY,0,'#ffbd61',.65,1.2,1);}
 if(data.accessory==='halo'){const halo=torus(body,.35,.023,0,1.73,0,'#ffd35c');halo.rotation.x=Math.PI/2;}
 root.userData.body=body;root.userData.limbs=limbs;root.userData.type=data.type;root.userData.height=data.type==='rocket'?1.65:1.7;
 const ring=mesh(new THREE.RingGeometry(.48,.51,40), '#ffcb85',root,0,.025,0,.8);ring.rotation.x=-Math.PI/2;ring.material.side=THREE.DoubleSide;ring.visible=false;ring.castShadow=false;root.userData.ring=ring;
 root.traverse(o=>{o.userData.agentId=data.id;});return root;
}
function signature(a){return [a.type,a.color,a.accessory].join('|');}
function syncAgents(){const liveIds=new Set();for(const [i,e]of B.entities().entries()){const a=e.data;liveIds.add(a.id);let actor=agents.get(a.id);if(actor&&actor.signature!==signature(a)){const old=actor.model;actor.model=model(a);actor.model.position.copy(old.position);actor.model.rotation.copy(old.rotation);scene.remove(old);old.traverse(o=>o.geometry?.dispose());scene.add(actor.model);actor.signature=signature(a);}
 if(!actor){const index=[15,23,28,31,11,20,36,40][i%8],root=model(a);root.position.copy(nodes[index]);scene.add(root);const label=document.createElement('button');label.type='button';label.className='agent-label-3d';label.setAttribute('aria-label','View agent '+a.name);label.innerHTML='<span class="floating-result"></span><span class="speech-3d"></span><span class="agent-name-3d"></span>';labels.append(label);label.onclick=()=>{B.select(a);};actor={model:root,label,index,from:index,next:adjacency[index][i%adjacency[index].length],progress:0,wait:i*.2,signature:signature(a),phase:i*.7};agents.set(a.id,actor);}
 actor.entity=e;actor.label.querySelector('.agent-name-3d').textContent=a.name;actor.label.setAttribute('aria-label','View agent '+a.name);actor.model.userData.ring.visible=B.isMine(a.id)||B.follow()===a.id;}
 for(const [id,actor]of agents)if(!liveIds.has(id)){scene.remove(actor.model);actor.label.remove();agents.delete(id);}}
const pointer=new THREE.Vector2(),raycaster=new THREE.Raycaster();let pointerStart=null;
canvas3d.addEventListener('pointerdown',e=>{pointerStart={x:e.clientX,y:e.clientY};});
canvas3d.addEventListener('pointerup',e=>{if(!pointerStart||Math.hypot(e.clientX-pointerStart.x,e.clientY-pointerStart.y)>6)return;const rect=canvas3d.getBoundingClientRect();pointer.set((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1);raycaster.setFromCamera(pointer,camera);const hit=raycaster.intersectObjects([...agents.values()].map(a=>a.model),true)[0];if(hit){const id=hit.object.userData.agentId,actor=agents.get(id);if(actor)B.select(actor.entity.data);}});
controls.addEventListener('start',()=>{B.setFollow(null);});
canvas3d.addEventListener('keydown',e=>{if(e.key==='Enter'){B.select(B.entities()[0].data);return;}if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();const angle=e.key==='ArrowLeft'?.13:e.key==='ArrowRight'?-.13:0;const relative=camera.position.clone().sub(controls.target);relative.applyAxisAngle(new THREE.Vector3(0,1,0),angle);camera.position.copy(controls.target).add(relative);if(e.key==='ArrowUp'||e.key==='ArrowDown')camera.zoom=THREE.MathUtils.clamp(camera.zoom+(e.key==='ArrowUp'?.15:-.15),.55,5);camera.updateProjectionMatrix();controls.update();}});
function home(top=false){B.setFollow(null);camera.position.set(...(top?[0,40,.5]:[24,29,28]));controls.target.set(0,.25,0);camera.zoom=1;camera.updateProjectionMatrix();controls.update();}
document.querySelector('#zoomIn').onclick=()=>{camera.zoom=Math.min(5,camera.zoom+.18);camera.updateProjectionMatrix();};document.querySelector('#zoomOut').onclick=()=>{camera.zoom=Math.max(.55,camera.zoom-.18);camera.updateProjectionMatrix();};document.querySelector('#resetView').onclick=()=>home();document.querySelector('#topView').onclick=()=>home(true);document.querySelector('#isoView').onclick=()=>home();document.querySelector('#exitExplore').onclick=()=>home();
document.querySelector('#tour').onclick=()=>{controls.autoRotate=!controls.autoRotate;controls.autoRotateSpeed=.6;document.querySelector('#tour').classList.toggle('selected',controls.autoRotate);document.querySelector('#tour').setAttribute('aria-pressed',String(controls.autoRotate));};
document.querySelector('#room').addEventListener('change',()=>{const r=B.room();document.querySelector('.edition-note').textContent='DISTRICT '+(r==='district'?'01':r==='garden'?'02':'03')+' / 3D WORLD';home();const x=r==='garden'?-16:r==='harbor'?16:0;controls.target.x=x;camera.position.x+=x;camera.zoom=1.65;camera.updateProjectionMatrix();controls.update();});
const resize=()=>{const w=innerWidth,h=innerHeight;renderer.setSize(w,h,false);const aspect=w/h,extent=Math.max(39,57/aspect);camera.left=-extent*aspect/2;camera.right=extent*aspect/2;camera.top=extent/2;camera.bottom=-extent/2;camera.updateProjectionMatrix();};addEventListener('resize',resize);resize();
let time=0,last=performance.now(),syncAt=0;const projected=new THREE.Vector3();
function frame(now){const dt=Math.min((now-last)/1000,.06);last=now;if(document.hidden){requestAnimationFrame(frame);return;}if(now-syncAt>350){syncAgents();syncAt=now;}
 if(!B.paused()){time+=dt;B.tick(dt);for(const actor of agents.values()){actor.phase+=dt*7;const floating=['rocket','whale'].includes(actor.model.userData.type);let moving=false;if(actor.wait>0)actor.wait-=dt;else{const from=nodes[actor.from],to=nodes[actor.next],dist=from.distanceTo(to);actor.progress+=dt*(.95+(actor.phase%1)*.06)/dist;moving=true;actor.model.position.lerpVectors(from,to,Math.min(actor.progress,1));const angle=Math.atan2(to.x-from.x,to.z-from.z);const delta=THREE.MathUtils.euclideanModulo(angle-actor.model.rotation.y+Math.PI,Math.PI*2)-Math.PI;actor.model.rotation.y+=delta*Math.min(1,dt*8);if(actor.progress>=1){const prior=actor.from;actor.index=actor.next;actor.from=actor.next;const choices=adjacency[actor.index].filter(n=>n!==prior);actor.next=(choices.length?choices:adjacency[actor.index])[Math.floor(Math.random()*(choices.length||adjacency[actor.index].length))];actor.progress=0;actor.wait=.5+Math.random()*2.7;}}
 const body=actor.model.userData.body;body.scale.y=1+Math.sin(time*2+actor.phase*.02)*.009;const blink=Math.sin(time*1.3+actor.phase*.01)> .997;actor.model.userData.eyes.forEach(e=>e.scale.y=blink?.12:1);if(actor.model.userData.steam){actor.model.userData.steam.position.y=1.28+Math.sin(time*1.7)*.05;actor.model.userData.steam.rotation.y=time*.25;}body.rotation.z=moving?Math.sin(actor.phase)*.025:Math.sin(time*1.2)*.012;body.position.y=floating?.15+Math.sin(time*2+actor.phase*.02)*.055:moving?Math.abs(Math.sin(actor.phase))*.025:0;
 actor.model.userData.limbs.forEach((limb,i)=>{if(actor.model.userData.type==='car')limb.rotation.x=moving?time*4:limb.rotation.x;else limb.rotation.x=moving?Math.sin(actor.phase+(i%2)*Math.PI)*.37:Math.sin(time)*.025;});if(actor.model.userData.tail)actor.model.userData.tail.rotation.y=Math.sin(actor.phase*.45)*.2;if(actor.model.userData.flame)actor.model.userData.flame.scale.y=1+Math.sin(time*12)*.15;
 }}
 for(const item of animated){if(!B.paused()){if(item.kind==='fan')item.object.rotation.y+=dt;else if(item.kind==='crystal'){item.object.rotation.y+=dt*.3;item.object.position.y=1.5+Math.sin(time)*.09;}else item.object.rotation.z+=dt*.17;}}
 const follow=B.follow();if(follow&&agents.has(follow)){const target=agents.get(follow).model.position.clone();target.y=.4;const delta=target.clone().sub(controls.target).multiplyScalar(Math.min(1,dt*3));controls.target.add(delta);camera.position.add(delta);}controls.update();document.querySelector('#zoomLabel').textContent=Math.round(camera.zoom*100)+'%';
 const worldVisible=document.body.dataset.view==='world';labels.hidden=!worldVisible;
 if(worldVisible){for(const actor of agents.values()){projected.copy(actor.model.position);projected.y+=actor.model.userData.height;projected.project(camera);const x=(projected.x*.5+.5)*innerWidth,y=(-projected.y*.5+.5)*innerHeight;actor.label.style.transform=`translate(-50%,-100%) translate(${x}px,${y}px)`;actor.label.style.display=projected.z>1||x<-100||x>innerWidth+100||y<-100||y>innerHeight+100?'none':'';const pop=actor.entity.popup,speech=actor.entity.bubble,t=B.time();const resultEl=actor.label.querySelector('.floating-result');resultEl.textContent=pop&&pop.until>t?pop.text:'';resultEl.className='floating-result '+(pop?.positive?'gain':'loss');const speechEl=actor.label.querySelector('.speech-3d');speechEl.textContent=speech&&speech.until>t?speech.text:'';actor.label.classList.toggle('mine',B.isMine(actor.entity.data.id));}renderer.render(scene,camera);}
 requestAnimationFrame(frame);
}
syncAgents();loading.remove();document.body.classList.add('world3d-ready');canvas3d.dataset.renderer='webgl';canvas3d.dataset.worldSize='48x32';canvas3d.dataset.pathNodes=String(nodes.length);requestAnimationFrame(frame);
